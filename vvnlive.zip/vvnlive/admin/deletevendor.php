<?php
include('include_db.php');
if(isset($_SESSION['start1']))
{

$vendorid=$_GET['vendorid'];



$sql2="SELECT businessid FROM   vendorbusinessdetail b WHERE vendorid='$vendorid'";
$result2=mysqli_query($con,$sql2);
while($row2=mysqli_fetch_array($result2))
{
	$businessid=$row2['businessid'];
	$sql3="DELETE FROM businessdetail where businessid='$businessid'";
	$result3=mysqli_query($con,$sql3);
	
	$sql4="DELETE FROM coupondetail where businessid='$businessid'";
	$result4=mysqli_query($con,$sql4);
	
	$sql5="DELETE FROM adsinformation WHERE businessid='$businessid'";
	$result5=mysqli_query($con,$sql5);
}

$sql6="DELETE FROM productdetail WHERE vendorid='$vendorid' ";
$result6=mysqli_query($con,$sql6);
$sql1="DELETE FROM vendordetail where vendorid='$vendorid'";
$result1=mysqli_query($con,$sql1) or die(mysqli_error($con));

$sql7="DELETE FROM vendorbusinessdetail WHERE vendorid='$vendorid' ";
$result7=mysqli_query($con,$sql7);
 echo "<script type='text/javascript'> window.location='vendor.php'</script>";
	
			
?>
  <?php }
else
{
  echo "<script type='text/javascript'> window.location='login.php'</script>"; 
}
?>
