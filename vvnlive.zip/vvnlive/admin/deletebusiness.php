<?php
include('include_db.php');
if(isset($_SESSION['start1']))
{

$businessid=$_GET['businessid'];

echo "1";

$sql1="DELETE FROM businessdetail WHERE businessid='$businessid'";
$result1=mysqli_query($con,$sql1);

$sql3="DELETE FROM productdetail WHERE businessid='$businessid'";
$result3=mysqli_query($con,$sql3);

$sql8="DELETE FROM coupondetail WHERE businessid='$businessid'";
$result8=mysqli_query($con,$sql8);

echo "2";


$sql4="SELECT businessid, vendorid FROM vendordetail WHERE businessid='$businessid'";
$result4=mysqli_query($con,$sql4);
echo "3";
if($result4)
{
	$row4=mysqli_fetch_array($result4);
	$vendorid=$row4['vendorid'];
	
	$sql6="SELECT businessid FROM vendorbusinessdetail WHERE vendorid='$vendorid'";
	$result6=mysqli_query($con,$sql6);
	if($result6)
	{
		$row6=mysqli_fetch_array($result6);
		$bid=$row6['businessid'];
		$sql7="UPDATE vendordetail SET businessid='$bid' FROM vendordetail WHERE vendorid='$vendorid'";
		$result7=mysqli_query($con,$sql7);
	}
	else
	{
		$sql2="UPDATE vendordetail SET businessid='0' FROM vendordetail WHERE vendorid='$vendorid'";
		$result2=mysqli_query($con,$sql2);
	}	
echo "4";
	
}
echo "5";
$sql5="DELETE FROM vendorbusinessdetail WHERE businessid='$businessid'";
$result5=mysqli_query($con,$sql5);	

 echo "<script type='text/javascript'> window.location='business.php'</script>";
?>
  <?php }
else
{
  echo "<script type='text/javascript'> window.location='login.php'</script>"; 
}
?>
