<?php
# FileName="connect.php"
$hostname = "103.248.81.32";
$database = "indiadea_vvnlive";
$username = "india_vvnlive";
$password = "dbRvi5L4151@3";
/*
$host="103.248.81.32";
$username="india_vvnlive";
$password="dbRvi5L4151@3";
$db_name="indiadea_vvnlive";
$con= new mysqli("$host","$username","$password","$db_name") or die("cannot connect");
*/
?>