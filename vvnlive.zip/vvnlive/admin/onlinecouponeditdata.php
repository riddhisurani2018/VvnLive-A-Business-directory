<?php
// Include the connect.php file
include('include_db.php');


// Connect to the database
//$mysqli = new mysqli($hostname, $username, $password, $database);
/* check connection */
if (mysqli_connect_errno())
	{
	printf("Connect failed: %s\n", mysqli_connect_error());
	exit();
	}
$query = "SELECT couponid,oid,categoryid,subcategoryid,ProductName,ProductPrice,DiscountedPrice,ProductURL,ProductImageSmallURL FROM onlinecoupon";
if (isset($_GET['update']))
	{
		
	// UPDATE COMMAND
	$query = "UPDATE `onlinecoupon` SET  `categoryid`=?, 'oid'=? `subcategoryid`=?, `ProductName`=?, `ProductPrice`=?, `DiscountedPrice`=?, `ProductURL`=? ,`ProductImageSmallURL`=?  WHERE `couponid`=?";
	$result = $con->prepare($query);
	$result->bind_param('sssssssss', $_GET['categoryid'],$_GET['oid'], $_GET['subcategory'], $_GET['ProductName'], $_GET['ProductPrice'], $_GET['DiscountedPrice'], $_GET['ProductURL'], $_GET['ProductImageSmallURL'],  $_GET['couponid']);
	$res = $result->execute() or trigger_error($result->error, E_USER_ERROR);
	// printf ("Updated Record has id %d.\n", $_GET['EmployeeID']);
	echo $res;
	}
  else
	{
	// SELECT COMMAND
	$result = $con->prepare($query);
	$result->execute();
	$result->bind_result( $couponid,$oid, $categoryid, $subcategory, $ProductName, $ProductPrice, $DiscountedPrice, $ProductURL, $ProductImageSmallURL);
	// fetch values
	while ($result->fetch())
		{
		$onlinecoupon[] = array(
			'couponid' => $couponid,
			'oid' => $oid,
			'categoryid' => $categoryid,
			'subcategoryid' => $subcategory,
			'ProductName' => $ProductName,
			'ProductPrice' => $ProductPrice,
			'DiscountedPrice' => $DiscountedPrice,
			'ProductURL' => $ProductURL,
			'ProductImageSmallURL' => $ProductImageSmallURL,
			
		);
		}
	echo json_encode($onlinecoupon);
	}
/* close statement */
$result->close();
/* close connection */
$con->close();
?>