<?php
include('include_db.php');
if(isset($_SESSION['start1']))
{

$pid=$_GET['productid'];

$sql="DELETE FROM productdetail where productid='$pid'";
$result=mysqli_query($con,$sql);


 echo "<script type='text/javascript'> window.location='business.php'</script>";
?>
  <?php }
else
{
  echo "<script type='text/javascript'> window.location='login.php'</script>"; 
}
?>
