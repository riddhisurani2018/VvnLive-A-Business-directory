<?php
include('include_db.php');
$sql="SELECT vendorid, businessid from vendordetail";
$result=mysqli_query($con,$sql);

while($r=mysqli_fetch_array($result))
{
	$bid=$r['businessid'];
	$vid=$r['vendorid'];
	echo $bid."-".$vid."<br /> ";
	$sql1="INSERT INTO vendorbusinessdetail (vendorid,businessid) VALUES ('$vid','$bid')";
	$result1=mysqli_query($con,$sql1);
	if($result1)
		echo "done <br />";
	else
		echo "fail";
}
?>