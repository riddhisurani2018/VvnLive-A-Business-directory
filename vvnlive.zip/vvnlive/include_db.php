<?php
session_start();

$host="103.248.81.32";
$username="india_vvnlive";
$password="Qvdi8^40";
$db_name="indiadea_vvnlive";
$con= new mysqli("$host","$username","$password","$db_name") or die("cannot connect");


/*
$host="localhost";
$username="root";
$password="";
$db_name="indiadea_vvnlive";
$con= new mysqli("$host","$username","$password","$db_name");
*/
?>